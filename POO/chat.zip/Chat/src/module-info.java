module chat {
	requires java.sql;
}
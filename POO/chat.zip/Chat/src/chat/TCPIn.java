package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class TCPIn implements Runnable {

	BufferedReader in = null;
	Client cl;
	String psd;

	public TCPIn(BufferedReader in, Client cl, String psd) {
		this.in = in;
		this.cl = cl;
		this.psd = psd;
	}

	@Override
	public void run() {
		System.out.println("TCPIn");
		while (true) {
			try {
				String str = in.readLine();
				while(str == null) {
					str = in.readLine();
					TimeUnit.SECONDS.sleep(2);
				}
				cl.msgs.add(psd + " : " + str);
				System.out.println(psd + " : " + str);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}

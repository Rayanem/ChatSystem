package chat;

import java.net.*;
import java.util.Scanner;
import java.io.*;

public class EngageChat {
	Socket socket;
	String str;
	String s;
	Client cl;
	int port;
	String psd;

	public EngageChat(String server, int port, String s, Client cl, String psd) throws IOException {
		// 1 Create server Socket
		System.out.println(port);
		socket = new Socket(server, port);
		this.port = port;
		this.s = s;
		this.cl = cl;
		this.psd = psd;
	}

	public void run() throws IOException {
		System.out.println("Running");
		BufferedReader in = null;
		try {
			in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		PrintWriter out = null;
		try {
			out = new PrintWriter(this.socket.getOutputStream(), true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.println(s);
		final BufferedReader parameter = in;
		Thread t = new Thread(new Runnable() {
			public void run() {
				while (true) {
					try {
						str = parameter.readLine();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (str != null) {
						cl.msgs.add(psd + " : " + str);
						System.out.println("re�u : " + str);
					}
				}
			}
		});
		t.start();
		while(true) {
			Scanner scan = new Scanner(System.in);
			while (!scan.hasNext()) {
			}
			String str = scan.nextLine();
			cl.msgs.add(cl.name + " : " + str);
			if(str.equals("quit"))
				cl.toDb(port-2000);
			out.println(str);
			out.flush();
		}
	}
}
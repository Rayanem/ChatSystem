package chat;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Main {
	public static void main(String[] args) {

		Interface in = new Interface();
		
		in.ft();
		/*
		Scanner scan = new Scanner(System.in);
		System.out.println("Veuillez saisir un port :");
		while (!scan.hasNext()) {
		}
		String str = scan.nextLine();
		System.out.println("port " + (Integer.parseInt(str)));
		Client cl = new Client(Integer.parseInt(str));
		cl.testName();
		try {
			TimeUnit.SECONDS.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 */
	}

}

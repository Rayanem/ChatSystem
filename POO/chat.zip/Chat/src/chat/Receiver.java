package chat;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Receiver {
	private String name = "toto";

	private int port;
	private Client cl;

	public Receiver(String name, int port, Client cl) {
		this.name = name;
		this.port = port;
		this.cl = cl;
		run();
	}
	
	public void setName(String str) {
		name = str;
	}

	public void run() {

		Thread t = new Thread(new Runnable() {
			public void run() {
				try {

					// Cr�ation de la connexion c�t� serveur, en sp�cifiant un port d'�coute
					DatagramSocket server = new DatagramSocket(port);

					while (true) {

						// On s'occupe maintenant de l'objet paquet
						byte[] buffer = new byte[8192];
						DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

						// Cette m�thode permet de r�cup�rer le datagramme envoy� par le client
						// Elle bloque le thread jusqu'� ce que celui-ci ait re�u quelque chose.
						server.receive(packet);

						// nous r�cup�rons le contenu de celui-ci et nous l'affichons
						byte[] data = packet.getData();
						int id = data[0];
						if (id == 127)
							System.out.println("Demande de pseudo");

						int client = data[1];
						data = Arrays.copyOfRange(data, 2, buffer.length);
						System.out.println(client);

						String str = new String(data, packet.getOffset(), packet.getLength() - 2);

						System.out.print("Re�u de la part de " + packet.getAddress() + " sur le port "
								+ packet.getPort() + " : ");
						System.out.println(str);

						// On r�initialise la taille du datagramme, pour les futures r�ceptions
						packet.setLength(buffer.length);

						// et nous allons r�pondre � notre client, donc m�me principe
						if (id == 127) {
							System.out.println("127");
							ClientTCP cli;
							try {
								TimeUnit.SECONDS.sleep(1);
								if (!(str.equals(name))) {
									System.out.println("OUI");
									System.out.println("ClientTCP " + (client + 4500));
									cli = new ClientTCP("127.0.0.1", (client + 4500));
									cli.run(port + "/" + name);
								} else {
									System.out.println("NON");
									cli = new ClientTCP("127.0.0.1", (client + 4500));
									cli.run("non");
								}
							} catch (InterruptedException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
						else if(id==2) {
							String[] arrSplit = str.split("/");
							if(!cl.map.containsValue(Integer.valueOf(arrSplit[0]))) {
								cl.map.put(arrSplit[1], Integer.valueOf(arrSplit[0]));
							}
							else {
								for (Entry<String, Integer> entry : cl.map.entrySet()) {
							        if (entry.getValue().equals(Integer.valueOf(arrSplit[0]))) {
							        	cl.map.remove(entry.getKey());
							            cl.map.put(arrSplit[1], Integer.valueOf(arrSplit[0]));
							        }
							    }
							}
								
							System.out.println(cl.map);
						}
						else if(id==3) {
							System.out.println("Voulez-vous discuter avec " + str + " ?");
							Scanner scan = new Scanner(System.in);
							while (!scan.hasNext()) {
							}
							String res = scan.nextLine();
							if(res.equals("oui")) {
								ServerSocket servSocket = new ServerSocket(port+2000);
								ArrayList<String> al = cl.db.get(port+2000, cl.map.get(str)+2000);
								for(int i =0;i<al.size();i++)
									System.out.println(al.get(i));
								EngageChat ec = new EngageChat("127.0.0.1", (cl.map.get(str)+2000),"Nouvelle connexion",cl,str);
								ec.run();
								/*
								ClientTCP cli = new ClientTCP("127.0.0.1", (cl.map.get(str) + 2000));
								Chat chat = new Chat(new Socket("127.0.0.1", (cl.map.get(str) + 2000)));
								cli.run("Bonjour");
								//cli.run("Salut");
								Thread th = new Thread(chat);
								th.start();
								*/
							}
						}
						
					}
				} catch (SocketException e) {
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		t.start();

	}

	public static synchronized void print(String str) {
		System.out.print(str);
	}

	public static synchronized void println(String str) {
		System.err.println(str);
	}
}
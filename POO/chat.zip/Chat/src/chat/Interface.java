package chat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;

import javax.swing.*;

public class Interface extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	JTextField tf1, tf2;
	JTextArea error;
	Client cl;
	JFrame f;
	JComboBox<String> cbnc;
	String otherDude;
	int port;
	
	JButton sendMessage;
	JTextField messageBox;
	public JTextArea chatBox = new JTextArea();
	
	EngageChat ec;
	
	public void ft() {

		f = new JFrame();// creating instance of JFrame

		tf1 = new JTextField();
		tf2 = new JTextField();
		JButton b = new JButton("Se connecter");// creating instance of JButton
		error = new JTextArea("Erreur ce pseudo est d�j� pris r�essayez");
		error.setBackground(Color.RED);

		b.setBounds(130, 100, 100, 40);
		b.addActionListener(this);
		b.setActionCommand("pseudo");

		tf1.setBounds(140, 50, 100, 20);
		tf2.setBounds(150, 30, 80, 20);

		error.setBounds(50, 200, 300, 20);

		f.add(b);// adding button in JFrame
		f.add(tf1);
		f.add(tf2);
		f.add(error);

		f.setSize(400, 500);// 400 width and 500 height
		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible

		error.setVisible(false);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		error.setVisible(false);
		String action = e.getActionCommand();
		if (action.equals("pseudo")) {
			cl = new Client(Integer.parseInt(tf2.getText()), tf1.getText(), this);
			if (!cl.testName()) {
				error.setVisible(true);
			} else {
				ft2();
			}
		} else if (action.equals("chat")) {
			cl.nouvelleConnexion((String) cbnc.getSelectedItem());
		} else if (action.equals("send")) {
			chatBox.append(cl.name + " : " + messageBox.getText() + "\n");
			if(cl.engaging)
				cl.chat.out(messageBox.getText());
			else
				ec.out(messageBox.getText());
		} else if (action.equals("accept")) {
			msg(otherDude,port);
		}
		
	}

	private void ft2() {
		f.dispatchEvent(new WindowEvent(f, WindowEvent.WINDOW_CLOSING));
		f = new JFrame();// creating instance of JFrame
		Set<String> set = cl.map.keySet();
		String[] myArray = new String[set.size()];
		set.toArray(myArray);

		JButton b = new JButton("Chat");// creating instance of JButton
		b.setBounds(130, 100, 100, 40);
		b.addActionListener(this);
		b.setActionCommand("chat");

		cbnc = new JComboBox<String>(myArray);

		cbnc.setBounds(140, 50, 100, 20);
		f.add(cbnc);
		f.add(b);

		f.setSize(400, 500);// 400 width and 500 height
		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible

	}

	
	public void ft4(String psd, int p) {

		otherDude = psd;
		port = p;

		JTextArea txt = new JTextArea("Voulez-vous discuter avec " + psd + " ?");

		f = new JFrame();// creating instance of JFrame

		JButton b1 = new JButton("Accepter");// creating instance of JButton
		JButton b2 = new JButton("Refuser");

		b1.setBounds(100, 100, 100, 40);
		b1.addActionListener(this);
		b1.setActionCommand("accept");

		b2.setBounds(200, 100, 100, 40);
		b2.addActionListener(this);
		b2.setActionCommand("deny");

		txt.setBounds(50, 20, 300, 20);

		f.add(b1);
		f.add(b2);
		f.add(txt);

		f.setSize(400, 500);// 400 width and 500 height
		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible

	}
	

	public void ft5() {

		f = new JFrame("ChatBox");

		f.setVisible(true);
		JPanel southPanel = new JPanel();
		f.add(BorderLayout.SOUTH, southPanel);
		southPanel.setBackground(Color.BLUE);
		southPanel.setLayout(new GridBagLayout());

		messageBox = new JTextField(30);
		sendMessage = new JButton("Envoyer Message");
		chatBox = new JTextArea();
		chatBox.setEditable(false);
		f.add(new JScrollPane(chatBox), BorderLayout.CENTER);
		
		sendMessage.addActionListener(this);
		sendMessage.setActionCommand("send");

		chatBox.setLineWrap(true);

		GridBagConstraints left = new GridBagConstraints();
		left.anchor = GridBagConstraints.WEST;
		GridBagConstraints right = new GridBagConstraints();
		right.anchor = GridBagConstraints.EAST;
		right.weightx = 2.0;

		southPanel.add(messageBox, left);
		southPanel.add(sendMessage, right);

		chatBox.setFont(new Font("Serif", Font.PLAIN, 15));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(600, 600);
		if(!cl.engaging)
			ec.box = chatBox;
		else
			cl.chat.box = chatBox;
	}
	
	public void msg(String psd, int p) {

		otherDude = psd;
		port = p;

		try {
			System.out.println(port + "  " + cl.map.get(otherDude));
			ArrayList<String> al = cl.db.get(port + 2000, cl.map.get(otherDude) + 2000);
			for (int i = 0; i < al.size(); i++)
				System.out.println(al.get(i));
			ec = new EngageChat("127.0.0.1", (cl.map.get(otherDude) + 2000), "Nouvelle connexion", cl,
					otherDude);
			Thread th = new Thread(ec);
			th.start();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ft5();
	}
	
	/*
	public void ft6(String psd, int p) {
		otherDude = psd;
		port = p;

		JTextArea txt = new JTextArea(psd + " a accept� votre demande");

		f = new JFrame();// creating instance of JFrame

		JButton b1 = new JButton("OK");

		b1.setBounds(100, 100, 100, 40);
		b1.addActionListener(this);
		b1.setActionCommand("accept");

		txt.setBounds(50, 20, 300, 20);

		f.add(b1);
		f.add(txt);

		f.setSize(400, 500);// 400 width and 500 height
		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible

		error.setVisible(false);
	}
	*/
}

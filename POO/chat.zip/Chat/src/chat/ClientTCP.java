package chat;
import java.net.*;
import java.io.*;

public class ClientTCP {
    Socket socket;

    public ClientTCP(String server, int port) throws IOException {
        //1 Create server Socket
    	System.out.println(port);
        socket = new Socket(server, port);
    }


    public void run(String str) throws IOException {
            BufferedReader in = null;
            try {
                in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
            PrintWriter out = null;
            try {
                out = new PrintWriter(this.socket.getOutputStream(),true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            out.println(str);
            out.println("fezfezf");
            out.println("ffffff");
            out.println("bbbb");
            System.out.println("re�u : " + in.readLine());
            in.close();
            out.close();
            this.socket.close();
    }

}
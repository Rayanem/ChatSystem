package chat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Database {

	/**
	 * This program demonstrates making JDBC connection to a SQLite database.
	 * 
	 * @author www.codejava.net
	 *
	 */

	public void insert(int port1, int port2, ArrayList<String> msgs) {
		try {
			Class.forName("org.sqlite.JDBC");
			String dbURL = "jdbc:sqlite:C:/sqlite/db/test.db";
			Connection conn = DriverManager.getConnection(dbURL);
			Statement stmt = conn.createStatement();
			if (conn != null) {
				System.out.println("Connected to the database");
				String database = "d" + port1 + "_" + port2;
				String sql = "CREATE TABLE IF NOT EXISTS " + database + " ( " + "msg VARCHAR(250) NOT NULL)";
				stmt.execute(sql);
				String sql2 = "INSERT INTO " + database + " (msg) VALUES(?)";
				PreparedStatement pstmt = conn.prepareStatement(sql2);
				for (int i = 0; i < msgs.size(); i++) {
					String msg = msgs.get(i);
					pstmt.setString(1, msg);
					pstmt.executeUpdate();
				}
				conn.close();
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public ArrayList<String> get(int port1, int port2) {
		ArrayList<String> al = new ArrayList<String>();
		try {
			Class.forName("org.sqlite.JDBC");
			String dbURL = "jdbc:sqlite:C:/sqlite/db/test.db";
			Connection conn = DriverManager.getConnection(dbURL);
			Statement stmt = conn.createStatement();
			if (conn != null) {
				System.out.println("Connected to the database");
				String database = "d" + port1 + "_" + port2;
				String sql = "SELECT msg FROM " + database;
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					al.add(rs.getString("msg"));
				}
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return al;
	}

	/*
	 * public static void main(String[] args) { ArrayList<String> str = new
	 * ArrayList<String>(); str.add("Bonjour"); str.add("fezfez"); str.add("jhjg");
	 * str.add("vxcvw"); str.add("rezre"); str.add("oiuo"); str.add("mlk");
	 * insert(999,888,str);
	 * 
	 * }
	 */
}

package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JTextArea;

public class Chat implements Runnable {
	ServerSocket servSocket;
	int prtdest;
	Socket link;
	boolean accept;
	Client cl;
	String psd;
	JTextArea box;
	PrintWriter out;

	public Chat(ServerSocket servSocket, int prtdest, Client cl,String psd) {
		this.servSocket = servSocket;
		this.prtdest = prtdest;
		this.accept = true;
		this.cl=cl;
		this.psd = psd;
	}
	

	public Chat(Socket socket) {
		link = socket;
		this.accept = false;
	}

	@Override
	public void run() {
		System.out.println("D�marrage chat with " + prtdest);
		if (accept) {
			System.out.println("accept");
			try {
				link = servSocket.accept();
			} catch (IOException e1) {

			}
		}
		BufferedReader in = null;
		if (link == null) {
			return;
		}
		try {
			in = new BufferedReader(new InputStreamReader(this.link.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		out = null;
		try {
			out = new PrintWriter(this.link.getOutputStream(), true);
		} catch (IOException e) {
			e.printStackTrace();
		}

		TCPIn tin = new TCPIn(in,cl,psd, prtdest,this);
		Thread thin = new Thread(tin);
		thin.start();
		/*
		TCPOut tout = new TCPOut(out,cl,prtdest,this);
		Thread thout = new Thread(tout);
		thout.start();*/
	}
	
	public void out(String next) {
		cl.msgs.add(cl.name + " : " + next);
		
		if(next.equals("quit")) {
			out.println(next);
			out.flush();
			cl.toDb(prtdest);
			try {
				servSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		out.println(next);
		out.flush();
	}

}

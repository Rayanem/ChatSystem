package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Chat implements Runnable {
	ServerSocket servSocket;
	int prtdest;
	Socket link;
	boolean accept;
	Client cl;
	String psd;

	public Chat(ServerSocket servSocket, int prtdest, Client cl,String psd) {
		this.servSocket = servSocket;
		this.prtdest = prtdest;
		this.accept = true;
		this.cl=cl;
		this.psd = psd;
	}
	

	public Chat(Socket socket) {
		link = socket;
		this.accept = false;
	}

	@Override
	public void run() {
		System.out.println("D�marrage chat with " + prtdest);
		if (accept) {
			System.out.println("accept");
			try {
				link = servSocket.accept();
			} catch (IOException e1) {

			}
		}
		BufferedReader in = null;
		if (link == null) {
			System.out.println("1");
			return;
		}
		try {
			in = new BufferedReader(new InputStreamReader(this.link.getInputStream()));
			System.out.println("1.5");
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("2");
		PrintWriter out = null;
		try {
			out = new PrintWriter(this.link.getOutputStream(), true);
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("3");
		TCPIn tin = new TCPIn(in,cl,psd);
		Thread thin = new Thread(tin);
		thin.start();
		TCPOut tout = new TCPOut(out,cl,prtdest);
		Thread thout = new Thread(tout);
		thout.start();
	}

}

package chat;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.*;
import java.util.concurrent.*;

public class Client {

	String name = "";
	public Map<String,Integer> map = new HashMap<String,Integer>();
	//public ArrayList<String> autre = new ArrayList<String>();
	private int port;
	Receiver rc;
	public Database db;
	public ArrayList<String> msgs;
	
	public Client(int port) {
		this.port = port;
		db = new Database();
		msgs = new ArrayList<String>();
		System.out.println("Client :" + port);
	}
	
	public void testName() {
		boolean ok = false;
		Scanner scan = new Scanner(System.in); 
		LinkedList<Sender> lsnd = new LinkedList<Sender>();
		for(int i=0;i<5;i++) {
			lsnd.add(new Sender((2500+i),port));
		}
		while(!ok) {
			System.out.println("Veuillez saisir un pseudo :");
			
			while(!scan.hasNext()) {}
			//System.out.println("test\n");
			String str = scan.nextLine();
			for(int i=0;i<5;i++) {
				lsnd.get(i).newPseudo(str);
			}
			try {
				if(tcp()) {
					ok=true;
					name = str;
				}
				else
					System.out.println("again\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//scan.close();
		System.out.println(map.keySet());
		
		for (int i : map.values()) {
			Sender snd = new Sender(i,port);
			snd.pseudoAccepted(port+"/"+name);
		}
		
		System.out.println("Receiver");
		rc = new Receiver(name,port,this);
		if(name.contentEquals("toto")) {
			System.out.println("Que faire ?");
			while(!scan.hasNext()) {}
			String str = scan.nextLine();
			if(str.equals("nouvelleco")) {

				nouvelleConnexion();
			}
		}
		/*
		else {
			changerPseudo();
		}*/
	}
	
	private void changerPseudo() {
		boolean ok = false;
		Scanner scan = new Scanner(System.in); 
		LinkedList<Sender> lsnd = new LinkedList<Sender>();
		for(int i=0;i<5;i++) {
			lsnd.add(new Sender((2500+i),port));
		}
		while(!ok) {
			System.out.println("Veuillez saisir un pseudo :");
			
			while(!scan.hasNext()) {}
			//System.out.println("test\n");
			String str = scan.nextLine();
			for(int i=0;i<5;i++) {
				lsnd.get(i).newPseudo(str);
			}
			try {
				if(tcp()) {
					ok=true;
					name = str;
					rc.setName(name);
				}
				else
					System.out.println("again\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//scan.close();
		System.out.println(map.keySet());
		
		for (int i : map.values()) {
			Sender snd = new Sender(i,port);
			snd.pseudoAccepted(port+"/"+name);
		}
	}

	private boolean tcp() throws IOException {
		int j = 0;
		ArrayList<ThreadTCP> list = new ArrayList<ThreadTCP>();
		ServerSocket servSocket = new ServerSocket(port+2000);
		ExecutorService es = Executors.newCachedThreadPool();

		while (j<5) {
			list.add(j, new ThreadTCP(servSocket));
			es.execute(list.get(j));
			System.out.println("D�marage");
			try {
				es.awaitTermination(1, TimeUnit.SECONDS);
			}
			catch(InterruptedException e) {
				System.out.println("rgbru");
			}
			j++;
		}
		System.out.println("TTT");
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(list.get(0).connected) {
			System.out.println("Oui");
			for(int i = 0; i<list.size();i++) {
				if(list.get(i).getResponse().isEmpty())
					break;
				if(list.get(i).getResponse().equals("non")) {
					servSocket.close();
					return false;
				}
				String[] arrSplit = list.get(i).getResponse().split("/");
				map.put(arrSplit[1], Integer.valueOf(arrSplit[0]));
			}
			servSocket.close();
			return true;
		}
		else {
			System.out.println("Non");
			//list.get(0).th.interrupt();
			servSocket.close();
			return true;
		}
	}
	
	private void nouvelleConnexion() {
		ServerSocket servSocket = null;
		System.out.println(map.keySet());
		Scanner scan = new Scanner(System.in);
		System.out.println("Veuillez saisir un pseudo :");
		while (!scan.hasNext()) {
		}
		String str = scan.nextLine();
		ArrayList<String> al = db.get(port+2000, map.get(str)+2000);
		for(int i =0;i<al.size();i++)
			System.out.println(al.get(i));
		Sender snd = new Sender(map.get(str),port);
		snd.message(name);
		try {
			servSocket = new ServerSocket(port+2000);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Chat chat = new Chat(servSocket,map.get(str),this,str);
		Thread th = new Thread(chat);
		th.start();
	}

	public void toDb(int portdest) {
		System.out.println("Sending to db");
		db.insert(port+2000, portdest+2000, msgs);
	}
	
	
}

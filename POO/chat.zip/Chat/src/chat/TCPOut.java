package chat;

import java.io.PrintWriter;
import java.util.Scanner;

public class TCPOut implements Runnable{
	
	PrintWriter out = null;
	Client cl;
	int port;

	public TCPOut(PrintWriter out, Client cl, int port) {
		this.out = out;
		this.cl = cl;
		this.port = port;
	}
	
	
	@Override
	public void run() {

		System.out.println("TCPOut");
		while(true) {
			Scanner scan = new Scanner(System.in);
			while (!scan.hasNext()) {
			}
			String next = scan.nextLine();
			cl.msgs.add(cl.name + " : " + next);
			if(next.equals("quit"))
				cl.toDb(port);
			out.println(next);
			out.flush();
		}
		
	}

}

package ChatSystem;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

import ChatSystem.Controller.ConnectionError;
import ChatSystem.Controller.SendDeconnectionError;
	
/**
 * Fenetre principale du programme
 *
 */
public class GUIMain extends JFrame{

	private static final long serialVersionUID = 1L;

	private static Controller controller;
	private Map<Integer, Boolean> newMessageGroups = new HashMap<Integer, Boolean>();
	private Map<Integer, Integer> nbMessagesGroups = new HashMap<Integer, Integer>();
	
	private JPanel panel; // Panel principal
	private JButton sendButton; // Bouton Envoyer 
	private JTextField textField; // Zone de texte
	private JEditorPane messagesArea; // Zone des messages
	private JScrollPane scrollMessageArea;
	private static JList<String> groupList; // Liste des groupes deja demarres
	private JList<String> connectedUsersList; // Liste des utilisateurs connectes
	private JLabel labelGroups; // Label "Conversations demarees"
	private JLabel labelConnectedUsers; // Label "Utilisateurs connectes"
	private JButton userButton; // Bouton "Profil"
	private JButton sendFileButton; // Bouton "Envoyer un fichier"
	private JButton deleteButton; // Bouton "Supprimer la conversation"
	
	/* Gestion du theme */
	public static String mainColor;
	public static String backgroundColor;
	public static String lightColor;
	public static String foreColor;
	
	@SuppressWarnings("unchecked")
	public GUIMain(String username) {
		
		/* Fenetre principale */
		super("Systeme de chat");

		addWindowListener(new windowClosingListener());
		setSize(new Dimension(900, 500));
		setLocationRelativeTo(null);
		
		
		/* Panel principal en mode grille */
		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.setBackground(new Color(200,200,200));
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(1,1,1,1);
		
		
		/* Bouton Envoyer */
		sendButton = new JButton("Envoyer le message");
		sendButton.addActionListener(new sendMessageListener());
		sendButton.setEnabled(false);
		sendButton.setBackground(Color.WHITE);
		sendButton.setIcon(new ImageIcon(getClass().getResource("/send.png")));
		sendButton.setHorizontalAlignment(SwingConstants.LEFT);
		sendButton.setIconTextGap(15);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.1;
		c.gridx = 3;
		c.gridy = 4;
		c.gridwidth = 1;
		c.gridheight = 1;
		panel.add(sendButton, c);
		
		
		/* Zone de texte */
		textField = new JTextField();
		textField.addActionListener(new sendMessageListener());
		textField.setBorder(null);
		textField.setEditable(false);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.6;
		c.gridx = 1;
		c.gridy = 4;
		c.gridwidth = 2;
		c.gridheight = 1;
		panel.add(textField, c);
		
		
		/* Zone des messages */
		messagesArea = new JEditorPane();
		messagesArea.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, Boolean.TRUE);
		messagesArea.setFont(textField.getFont());
		messagesArea.setContentType("text/html");
		messagesArea.setEditable(false);
		messagesArea.setMinimumSize(new Dimension(600, 600));
		messagesArea.setMaximumSize(new Dimension(600, 600));
        messagesArea.setPreferredSize(new Dimension(600, 600));
		
		scrollMessageArea = new JScrollPane(messagesArea);
		scrollMessageArea.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollMessageArea.setBorder(null);
		
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.8;
		c.weighty = 1;
		c.gridx = 1;
		c.gridy = 0;
		c.gridwidth = 2;
		c.gridheight = 4;
		panel.add(scrollMessageArea, c);
		
		
		/* Liste des groupes deja demarres */
		DefaultListModel<String> groupnames = new DefaultListModel<String>();
		groupList = new JList<String>();
		groupList.setModel(groupnames);
		groupList.setPreferredSize(new Dimension(40,0));
		groupList.addListSelectionListener(new groupListSelectionChange());
		groupList.setCellRenderer(new MyListCellThing(MyListCellThing.STYLE_GROUP));
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.1;
		c.weighty = 1;
		c.gridx = 0;
		c.gridy = 1;
		c.gridheight = 4;
		c.gridwidth = 1;
		panel.add(groupList, c);
		
		labelGroups = new JLabel("Conversations demarrees", SwingConstants.CENTER);
		Font font = labelGroups.getFont();
		labelGroups.setFont(new Font(font.getName(), Font.PLAIN, 11));
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.1;
		c.weighty = 0.01;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.gridheight = 1;
		panel.add(labelGroups, c);
		
		
		/* Liste de tous les utilisateurs connectes */
		DefaultListModel<String> usernames = new DefaultListModel<String>();
		connectedUsersList = new JList<String>(usernames);
		connectedUsersList.setPreferredSize(new Dimension(40,0));
		connectedUsersList.addListSelectionListener(new connectedUsersListSelectionChange());
		connectedUsersList.setCellRenderer(new MyListCellThing(MyListCellThing.STYLE_USERS));
		c.weightx = 0.1;
		c.weighty = 2;
		c.gridx = 3;
		c.gridy = 3;
		c.gridheight = 1;
		c.gridwidth = 1;
		panel.add(connectedUsersList, c);
		
		labelConnectedUsers = new JLabel("Utilisateurs connectes", SwingConstants.CENTER);
		font = labelConnectedUsers.getFont();
		labelConnectedUsers.setFont(new Font(font.getName(), Font.PLAIN, 11));
		c.weightx = 0.1;
		c.weighty = 0.01;
		c.gridx = 3;
		c.gridy = 3;
		c.gridwidth = 1;
		c.gridheight = 1;
		panel.add(labelConnectedUsers, c);
		
		
		/* Bouton "Profil" */
		userButton = new JButton("Editer mon profil");
		userButton.addActionListener(new editUserListener(this));
		userButton.setBackground(Color.WHITE);
		userButton.setIcon(new ImageIcon(getClass().getResource("/profile.png")));
		userButton.setHorizontalAlignment(SwingConstants.LEFT);
		userButton.setIconTextGap(15);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.1;
		c.gridx = 3;
		c.gridy = 0;
		c.gridwidth = 1;
		c.gridheight = 1;
		panel.add(userButton, c);
		
		
		/* Bouton "Envoyer un fichier" */
		sendFileButton = new JButton("Envoyer un fichier");
		sendFileButton.setEnabled(false);
		sendFileButton.setBackground(Color.WHITE);
		sendFileButton.setIcon(new ImageIcon(getClass().getResource("/sendfile.png")));
		sendFileButton.setHorizontalAlignment(SwingConstants.LEFT);
		sendFileButton.setIconTextGap(15);
		sendFileButton.addActionListener(new sendFileListener());
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.1;
		c.gridx = 3;
		c.gridy = 1;
		c.gridwidth = 1;
		c.gridheight = 1;
		panel.add(sendFileButton, c);
		
		
		/* Bouton "Supprimer la conversation" */
		deleteButton = new JButton("Supprimer la conversation");
		deleteButton.addActionListener(new deleteConversationListener(this));
		deleteButton.setBackground(Color.WHITE);
		deleteButton.setIcon(new ImageIcon(getClass().getResource("/delete.png")));
		deleteButton.setHorizontalAlignment(SwingConstants.LEFT);
		deleteButton.setIconTextGap(15);
		deleteButton.setEnabled(false);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.1;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		panel.add(deleteButton, c);
		
		
		/* Icone du programme */
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/icon.png")));
		
		
		/* Theme sombre */
		if(DataManager.getASetting("general", "theme", "dark").equals("dark")) {
			mainColor = "#3A3E43";
			backgroundColor = "#2D3136";
			lightColor = "#4A4E53";
			foreColor = "#FAFAFA";
			
			panel.setBackground(Color.decode(backgroundColor));
			groupList.setBackground(Color.decode(mainColor));
			labelGroups.setForeground(Color.decode(foreColor));
			connectedUsersList.setBackground(Color.decode(mainColor));
			labelConnectedUsers.setForeground(Color.decode(foreColor));
			messagesArea.setBackground(Color.decode(mainColor));
			textField.setBackground(Color.decode(mainColor));
			textField.setForeground(Color.decode(foreColor));
			sendButton.setBackground(Color.decode(lightColor));
			sendButton.setOpaque(true);
			sendButton.setBorderPainted(false);
			sendButton.setForeground(Color.decode(foreColor));
			sendFileButton.setBackground(Color.decode(lightColor));
			sendFileButton.setForeground(Color.decode(foreColor));
			sendFileButton.setOpaque(true);
			sendFileButton.setBorderPainted(false);
			userButton.setBackground(Color.decode(lightColor));
			userButton.setForeground(Color.decode(foreColor));
			userButton.setOpaque(true);
			userButton.setBorderPainted(false);
			deleteButton.setBackground(Color.decode(lightColor));
			deleteButton.setForeground(Color.decode(foreColor));
			deleteButton.setOpaque(true);
			deleteButton.setBorderPainted(false);
		}
		else {
			mainColor = "#FFFFFF";
			backgroundColor = "#C8C8C8";
			lightColor = "#E6E6E6";
			foreColor = "#000000";
		}
		
		/* Affichage */
		add(panel);
		setVisible(true);
		
	}
	
	/**
	 * Permet de mettre en forme les listes des groupes et des utilisateurs connectes
	 */
	@SuppressWarnings("rawtypes")
	public class MyListCellThing extends JLabel implements ListCellRenderer {
		
		private static final long serialVersionUID = 1L;

		private int style;
		
		// Pour ne pas mettre en gras le nom des utilisateurs connectes (uniquement les groupes)
		public static final int STYLE_GROUP = 1;
		public static final int STYLE_USERS = 2;

		/**
		 * Cree une nouvelle liste
		 * @param style Style de la liste
		 */
	    public MyListCellThing(int style) {
	        setOpaque(true);
	        this.style = style;
	    }
	    
	    /**
	     * Permet de definir le rendu graphique de la liste
	     * @param list Liste du composant
	     * @param value Valeur choisie
	     * @param index Index de l'objet selectionne
	     * @param isSelected Indique si un Objet est choisi
	     * @param cellHasFocus Indique si la cellule est en selection
	     */
	    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {

	        setText(value.toString());

	        String groupName = list.getModel().getElementAt(index).toString();
	        Group selectedGroup = controller.getGroupByName(groupName);

	        // On met en gras dans la liste des groupes si nouveau message
	        if(style == STYLE_GROUP && selectedGroup != null &&
	        	newMessageGroups.containsKey(selectedGroup.getGroupId()) && newMessageGroups.get(selectedGroup.getGroupId())) {
	        	if (nbMessagesGroups.containsKey(selectedGroup.getGroupId())) {
	        		int i = nbMessagesGroups.get(selectedGroup.getGroupId());
	        		setText(value.toString() + " " + i);
	        	}
	        	setFont(getFont().deriveFont(Font.BOLD));
	        	if (controller.getGroupByName(groupList.getSelectedValue())!=null && 
	        			selectedGroup.getGroupId() == controller.getGroupByName(groupList.getSelectedValue()).getGroupId() && 
	        			nbMessagesGroups.containsKey(selectedGroup.getGroupId())) {
					nbMessagesGroups.remove(selectedGroup.getGroupId());
					setText(value.toString());
		        }
	        }
	        else {
	        	setFont(getFont().deriveFont(Font.PLAIN));
	        	setText(value.toString());
	        }

	        // Coloration de l'item selectionne
	        if(isSelected)
	        	setBackground(Color.decode(lightColor));
	        
	        else
	        	setBackground(Color.decode(mainColor));
	        
	        setForeground(Color.decode(foreColor));
	        setBorder(new EmptyBorder(10, 10, 10, 10));

	        return this;
	    }
	}
	

	/***************************** LISTENERS *****************************/
	
	/**
	 * Listener du bouton "Profil"
	 */
	public class editUserListener implements ActionListener {
		private GUIMain gui;
		
		public editUserListener(GUIMain guiMain) {
			super();
			this.gui = guiMain;
		}
		
		// Affichage de la fenetre de profil
		public void actionPerformed(ActionEvent e) {			
			setEnabled(false);
			new GUIUserEdit(gui, controller);			
		}
	}
	
	/**
	 * Listener du bouton de suppression de conversation
	 */
	public class deleteConversationListener implements ActionListener {
		
		public deleteConversationListener(GUIMain guiMain) {
			super();
		}
		
		public void actionPerformed(ActionEvent e) {
			String groupName = groupList.getSelectedValue();
			controller.removeMessagesGroup(controller.getGroupByName(groupName));
			displayMessages(controller.getGroupByName(groupName));
		}
	}
	
	
	/**
	 * Listener de l'envoi d'un message
	 */
	public class sendMessageListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			
			// Texte a envoyer
			String textToSend = textField.getText();
			
			if(textToSend.equals(""))
				return;
			
			
			/* Envoi du message */
			try {
				if(connectedUsersList.getSelectedIndex() == -1)
					return;
				
				// Obtention du groupe a partir de son nom
				String groupName = connectedUsersList.getSelectedValue();
				
				// Envoi du message
				controller.sendMessage(textToSend, groupName, Message.NORMAL_FUNCTION);
				
				// RAZ de la zone de texte
				textField.setText(null);
				displayMessages(controller.getGroupByName(groupName));
			
			} catch (Exception e1) {
				showError("Impossible d'envoyer le message a cet utilisateur.");
			}

		}
		
	}
	
	/**
	 * Listener de l'envoi d'un fichier
	 */
	public class sendFileListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			
			// Selection du fichier a envoyer
			JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
			chooser.setDialogTitle("Selectionner le fichier a envoyer");
			chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			chooser.setMultiSelectionEnabled(false);
			int returnValue = chooser.showDialog(null, "Envoyer");
			
			// On envoie le message que si l'utilisateur le veut
			if(returnValue == JFileChooser.APPROVE_OPTION) {
				
				/* Envoi du fichier */
				try {
					if(connectedUsersList.getSelectedIndex() == -1)
						return;
					
					// Obtention du groupe a partir de son nom
					String groupName = connectedUsersList.getSelectedValue();
					
					// Envoi du message
					File selectedFile = chooser.getSelectedFile();
					controller.sendMessage(selectedFile.toString(), groupName, Message.FILE_FUNCTION);
					
					displayMessages(controller.getGroupByName(groupName));
				
				} catch (Exception e1) {
					showError("Impossible d'envoyer le fichier a cet utilisateur.");
				}
				
			}
				
		}
		
	}
	
	/**
	 * Listener de la fermeture de la fenetre
	 */
	public class windowClosingListener implements WindowListener {
		
		public void windowClosing(WindowEvent e) {
			
			try {
				// Deconnexion de l'utilisateur
				controller.disconnection();
				
				// Fin du programme sans erreur
				System.exit(Controller.EXIT_WITHOUT_ERROR);
			} catch (ConnectionError | SendDeconnectionError err) {
				showError("Une erreur est survenue lors de la connexion au serveur.");
				System.exit(Controller.EXIT_ERROR_SEND_DECONNECTION);
			} catch (IOException err) {
				showError("Une erreur est survenue lors de la deconnexion.");
				System.exit(Controller.EXIT_ERROR_SEND_DECONNECTION);
			}

		}
		
		public void windowOpened(WindowEvent arg0) {}
		public void windowClosed(WindowEvent arg0) {}
		public void windowIconified(WindowEvent arg0) {}
		public void windowDeiconified(WindowEvent arg0) {}
		public void windowActivated(WindowEvent arg0) {}
		public void windowDeactivated(WindowEvent arg0) {}

	}
	
	/**
	 * Listener du changement de groupe selectionne
	 */
	public class groupListSelectionChange implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			
			if(!e.getValueIsAdjusting()) {
				
				Group selectedGroup = controller.getGroupByName(groupList.getSelectedValue());
				
				// Selection de l'utilisateur correspond (si connecte)
				int index;
				boolean inList = false;
				for (index = 0; index < connectedUsersList.getModel().getSize(); index++) {
					String username = connectedUsersList.getModel().getElementAt(index);
					if (username.equals(groupList.getSelectedValue())) {
						connectedUsersList.setSelectedIndex(index);
						inList = true;
					} 
				}
				if (inList == false) {
					connectedUsersList.clearSelection();
					textField.setEditable(false);		
					sendButton.setEnabled(false);
					sendFileButton.setEnabled(false);
				}
				else {
					deleteButton.setEnabled(true);
				}
				
				
				// Rafraichissement des messages
				displayMessages(selectedGroup);
				
				if(selectedGroup != null)
					newMessageGroups.put(selectedGroup.getGroupId(), false);
			}

		}

	}
	
	/**
	 * Listener du changement d'utilisateur connecte selection
	 */
	public class connectedUsersListSelectionChange implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			
			if(!e.getValueIsAdjusting()) {
				
				int v = connectedUsersList.getSelectedIndex();
				
				// (Des)activation de la zone de texte et du bouton "Envoyer"
				if(connectedUsersList.getSelectedIndex() == -1) {
					textField.setEditable(false);
					sendButton.setEnabled(false);
					sendFileButton.setEnabled(false);
				}
				else {
					textField.setEditable(true);
					sendButton.setEnabled(true);
					deleteButton.setEnabled(true);
					sendFileButton.setEnabled(true);
				}
				
				// Selection du groupe corespondant
				Boolean bool = false;
				for(int index = 0; index < groupList.getModel().getSize(); index ++) {
					String username = groupList.getModel().getElementAt(index);
					
					if (username.equals(connectedUsersList.getSelectedValue())){
						groupList.setSelectedIndex(index);
						textField.requestFocusInWindow();
						bool = true;
						break;
					}
				}
				if (!bool && connectedUsersList.getSelectedIndex() != -1){
					groupList.setSelectedValue(null, false);
					connectedUsersList.setSelectedIndex(v);
					textField.requestFocusInWindow();
				}
				
			}
			
		}
		
	}
	
	/***************************** Methodes diverses *****************************/
	
	/**
	 * Met a jour la liste des utilisateurs connectes (GUI)
	 */
	public void updateConnectedUsers() {
		
		String prevSelected = groupList.getSelectedValue();
		
		DefaultListModel<String> usernames = new DefaultListModel<String>();
		ArrayList<User> connectedUsers;
		connectedUsers = controller.getConnectedUsers();
		
		int selectedIndex = -1;
		int i = 0;
		for(User u : connectedUsers) {
			if(u.getUsername().equals(prevSelected))
				selectedIndex = i;
			
			usernames.addElement(u.getUsername());
			
			i++;
		}
		
		connectedUsersList.setModel(usernames);
		
		// Garde l'utilisateur selectionne
		if(selectedIndex >= 0)
			connectedUsersList.setSelectedIndex(selectedIndex);
	}
	
	/**
	 * Met a jour les noms de la liste des groupes (GUI)
	 * @param updatedGroup Le groupe recevant un nouveau message (null si c'est un clic de l'utilisateur)
	 */
	public void setGroupNoRead(Group updatedGroup) {
		
		// Indique qu'il y a un nouveau message pour updatedGroup
		newMessageGroups.put(updatedGroup.getGroupId(), true);
		
		if (nbMessagesGroups.containsKey(updatedGroup.getGroupId())) {
			int j = nbMessagesGroups.get(updatedGroup.getGroupId());
			nbMessagesGroups.put(updatedGroup.getGroupId(),j+1);
		}
		else {
			nbMessagesGroups.put(updatedGroup.getGroupId(),1);
		}
		
		DefaultListModel<String> groupNames = new DefaultListModel<String>();
		
		String selectedGroupName = groupList.getSelectedValue();
		int selectedIndex = -1;
		
		for(int i=0; i<groupList.getModel().getSize(); i++) {
			String groupName = groupList.getModel().getElementAt(i);
			groupNames.addElement(groupName);
			
			if(groupName.equals(selectedGroupName))
				selectedIndex = i;
		}
		
		groupList.setModel(groupNames);
		
		// Garde le groupe selectionne
		if(selectedIndex >= 0)
			groupList.setSelectedIndex(selectedIndex);
		
	}
	
	/**
	 * Permet de selectionner un groupe dans la liste
	 * @param selectedGroup Le groupe a selectionner
	 */
	public void selectGroupInList(Group selectedGroup) {
		
		// Cherche le groupe dans la liste a partir de son nom
		String selectedGroupName = selectedGroup.getGroupNameForAUser(controller.getUser());
		int selectedIndex = -1;
		
		for(int i=0; i<groupList.getModel().getSize(); i++) {
			String groupName = groupList.getModel().getElementAt(i);
			
			if(groupName.equals(selectedGroupName))
				selectedIndex = i;
		}
		
		// Garde le groupe selectionne
		if(selectedIndex >= 0)
			groupList.setSelectedIndex(selectedIndex);
	}
	
	/**
	 * Permet de modifier le username d'un utilisateur dans les deux listes
	 * @param oldUsername L'ancien username
	 * @param newUsername Le nouveau username
	 */
	public void replaceUsernameInList(String oldUsername, String newUsername) {
		
		// Remplacement dans la liste des groupes
		int selectedIndex = groupList.getSelectedIndex();
		DefaultListModel<String> groupNames = new DefaultListModel<String>();
		
		for(int i=0; i<groupList.getModel().getSize(); i++) {
			String groupName = groupList.getModel().getElementAt(i);
			
			if(groupName.equals(oldUsername))
				groupNames.addElement(newUsername);
			else
				groupNames.addElement(groupName);
		}
		
		groupList.setModel(groupNames);
		
		if(selectedIndex >= 0)
			groupList.setSelectedIndex(selectedIndex);
		
		
		
		// Remplacement dans la liste des utilisateurs connectes
		selectedIndex = connectedUsersList.getSelectedIndex();
		DefaultListModel<String> usernames = new DefaultListModel<String>();
		
		for(int i=0; i<connectedUsersList.getModel().getSize(); i++) {
			String username = connectedUsersList.getModel().getElementAt(i);
			
			if(username.equals(oldUsername))
				usernames.addElement(newUsername);
			else
				usernames.addElement(username);
		}
		
		connectedUsersList.setModel(usernames);
		
		if(selectedIndex >= 0)
			connectedUsersList.setSelectedIndex(selectedIndex);
		
	}
	
	/**
	 * Permet d'ajouter un groupe a la liste
	 * @param group Le groupe a ajouter
	 */
	public void addGroup(Group group) {
		
		DefaultListModel<String> groupNames = new DefaultListModel<String>();
		
		String selectedGroupName = groupList.getSelectedValue();
		int selectedIndex = -1;
		
		for(int i=0; i<groupList.getModel().getSize(); i++) {
			String groupName = groupList.getModel().getElementAt(i);
			groupNames.addElement(groupName);
			
			if(groupName.equals(selectedGroupName))
				selectedIndex = i;
		}
		
		groupNames.addElement(group.getGroupNameForAUser(controller.getUser()));
		
		groupList.setModel(groupNames);
		
		if(selectedIndex >= 0)
			groupList.setSelectedIndex(selectedIndex);
		
	}
	
	/**
	 * Permet de rafraichir la zone des messages pour le groupe selectionne
	 * @param selectedGroup Le groupe dont les messages doivent etre affiches (null si le groupe n'existe pas ou aucun selectionne)
	 */
	private void displayMessages(Group selectedGroup) {
		
		if(selectedGroup != null) {
			messagesArea.setVisible(true);
			ArrayList<Message> groupMessages = controller.getGroupMessages(selectedGroup);
			
			String history = "<style type='text/css'>"
					+ ".message-sent{margin:3px 5px 3px 50px;padding:0 5px 5px 5px;background:#FF8075;color:white;font-size:14pt;}"
					+ ".message-received{margin:3px 50px 3px 5px;padding:0 5px 5px 5px;background:#eeeeee;color:black;font-size:14pt;}"
					+ ".date-sent{font-size:11pt;color:white;}"
					+ ".date-received{font-size:11pt;color:black;}"
					+ ".user-sent{font-size:11pt;color:#888888;margin:3px 0 0 55px;}"
					+ ".user-received{font-size:11pt;color:#888888;margin:3px 0 0 10px;}"
					+ "</style>";
			
			// Utilise pour ne pas repeter le nom de l'utilisateur si plusieurs messages consecutifs
			User prevSender = null;
			
			for(Message m : groupMessages) {
				String username, date, content = m.getMsg();
				
				// Format du contenu
				// Si image
				if(m.getFunction() == Message.IMAGE_FUNCTION) {
					File file = new File(content);
					
					// On l'affiche si elle existe encore sur le disque
					if(file.exists()) {
						content = "<img src='file:" + content + "' width='300' height='300' alt='image' />";
					}
					else {
						if(m.getSender().equals(controller.getUser()))
							content = "Vous avez envoye une image :<br/>";
						else
							content = "Vous avez recu une image :<br/>";
						
						content += "<strong>" + file.getName() + "</strong>";
					}
					
				}
				
				// Si fichier
				else if(m.getFunction() == Message.FILE_FUNCTION) {
					File file = new File(content);
					
					if(m.getSender().equals(controller.getUser()))
						content = "Vous avez envoye un fichier :<br/>";
					else
						content = "Vous avez recu un fichier :<br/>";
						
					content += "<strong>" + file.getName() + "</strong>";
				}
				
				// Format de la date
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
				date = dateFormat.format(m.getDateMsg());
				
				// Message envoye par moi
				if(m.getSender().equals(controller.getUser())) {
					username = "<div class='user-sent'>Moi</div>";
					date = "<span class='date-sent'>" + date + "</span>";
					content = "<div class='message-sent'>" + date + "<br>" + content + "</div>";
				}
				// Message envoye par l'autre utilisateur
				else {
					username = "<div class='user-received'>" + m.getSender().getUsername() + "</div>";
					date = "<span class='date-received'>" + date + "</span>";
					content = "<div class='message-received'>" + date + "<br>" + content + "</div>";
				}
				
				if(m.getSender().equals(prevSender))
					history += content;
				else
					history += username + content;
				
				prevSender = m.getSender();
			}

			// Affichage des messages
			messagesArea.setText(history);
			
			// Scroll a la fin des messages
			messagesArea.setCaretPosition(messagesArea.getDocument().getLength());
			
		}
		else {
			messagesArea.setText(null);
		}
		
	}
	
	/**
	 * Affiche une erreur a l'utilisateur
	 * @param errorMessage Le message d'erreur a afficher
	 */
	public static void showError(String errorMessage) {
		JOptionPane.showMessageDialog(null, errorMessage, "Erreur", JOptionPane.ERROR_MESSAGE);
	}


	public static void main(String[] args) throws SocketException, ClassNotFoundException, SQLException, UnknownHostException {	
		
		//Handling du SIGINT sur MAC OS X qui cause beaucoup de bugs
		String osName = System.getProperty("os.name").toLowerCase();
 		boolean isMacOs = osName.startsWith("mac os x");
 		if (isMacOs) {		
 			System.setProperty("apple.eawt.quitStrategy", "CLOSE_ALL_WINDOWS");
 		}

		// Recupere la liste des adresses IP que possede la machine (et les adresses de broadcast correspondantes)
		Map<InetAddress, InetAddress> allIP = Controller.getAllIpAndBroadcast();
		InetAddress ipMachine;
		String username;
		int id;
		GUIConnect guiConnect = new GUIConnect(new ArrayList<InetAddress>(allIP.keySet()));
		
		// Attente de la connexion de l'utilisateur
		while(guiConnect.getStatusConnexion() == false);		
		ipMachine = guiConnect.getIPSelected();
		username = guiConnect.getUsername();
		id = guiConnect.getId();
		
		try {

			// On teste la connexion du serveur ici pour ne pas afficher la fenetre principale s'il y a une erreur
			boolean useServer = (DataManager.getASetting("general", "use_server", "0").equals("1")) ? true : false;
			
			if(useServer) {
				String serverIP = DataManager.getASetting("server", "ip", "0.0.0.0");
				int serverPort = Integer.parseInt(DataManager.getASetting("server", "port", "-1"));
				
				// Cree le controller en utilisant le serveur
				controller = new Controller(allIP.get(ipMachine), serverIP, serverPort);
				
				if(!Controller.testConnectionServer()) {
					showError("Impossible de se connecter au serveur.\nVerifiez la configuration de la connexion ou utilisez le protocole UDP.");
					System.exit(Controller.EXIT_ERROR_SERVER_UNAVAILABLE);
				}
			}
			else {
				// Cree le controller sans serveur (utilisation de UDP)
				controller = new Controller(allIP.get(ipMachine), null, -1);
			}
			
			controller.setGUIMain(new GUIMain(username));
			controller.connection(id, username, ipMachine);

		} catch (NumberFormatException e) {
			// Mauvaise configuration du timeout dans le fichier ini
			showError("Impossible de se connecter au chat.\nVerifiez la configuration de la connexion au serveur ou du protocole UDP.");
			System.exit(Controller.EXIT_ERROR_SERVER_UNAVAILABLE);
		} catch (IOException e) {
			showError("Une erreur s'est produite dans la decouverte du reseau (Protocole UDP).");
			System.exit(Controller.EXIT_GET_CONNECTED_USERS);
		}
		
	}
}
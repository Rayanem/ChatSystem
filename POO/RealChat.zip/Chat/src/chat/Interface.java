package chat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;

import javax.swing.*;

public class Interface extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	JTextField tf1, tf2;
	JTextArea error;
	Client cl;
	JFrame f;
	JComboBox<String> cbnc;
	String otherDude;
	int port;
	int nb = -1;
	int nb2=0;

	JButton sendMessage,valid;
	JTextField messageBox;
	public JTextArea chatBox = new JTextArea();

	ArrayList<EngageChat> lec = new ArrayList<EngageChat>();
	
	DefaultComboBoxModel<String> model;

	public void ft() {

		f = new JFrame();// creating instance of JFrame

		tf1 = new JTextField();
		tf2 = new JTextField();
		JButton b = new JButton("Se connecter");// creating instance of JButton
		error = new JTextArea("Erreur ce pseudo est d�j� pris r�essayez");
		error.setBackground(Color.RED);

		b.setBounds(130, 100, 100, 40);
		b.addActionListener(this);
		b.setActionCommand("pseudo");

		tf1.setBounds(140, 50, 100, 20);
		tf2.setBounds(150, 30, 80, 20);

		error.setBounds(50, 200, 300, 20);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(b);// adding button in JFrame
		f.add(tf1);
		f.add(tf2);
		f.add(error);

		f.setSize(400, 500);// 400 width and 500 height
		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible

		error.setVisible(false);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		error.setVisible(false);
		String action = e.getActionCommand();
		if (action.equals("pseudo")) {
			System.out.println(Integer.parseInt(tf2.getText()) + 2500);
			cl = new Client(Integer.parseInt(tf2.getText()) + 2500, tf1.getText(), this);
			if (!cl.testName()) {
				error.setVisible(true);
			} else {
				ft2();
			}
		} else if (action.equals("chat")) {
			nb++;
			lec.add(null);
			cl.nouvelleConnexion((String) cbnc.getSelectedItem(), nb);
			System.out.println("----->  " + lec.size());
		} else if (action.equals("accept")) {
			nb++;
			msg(otherDude, port);
		} else if(action.equals("refresh")) {
			refresh();
		}else if(action.equals("change")) {
			tf1.setVisible(true);
			valid.setVisible(true);
		}else if(action.equals("valid")) {
			error.setVisible(false);
			if(!cl.changerPseudo(tf1.getText()))
				error.setVisible(true);
		}
	}

	private void ft2() {
		f.setVisible(false);
		//f.dispatchEvent(new WindowEvent(f, WindowEvent.WINDOW_CLOSING));
		f = new JFrame();// creating instance of JFrame
		JButton refresh = new JButton("Refresh");
		refresh.setBounds(250, 50, 100, 20);
		refresh.addActionListener(this);
		refresh.setActionCommand("refresh");
		
		JButton b = new JButton("Chat");// creating instance of JButton
		b.setBounds(130, 100, 100, 40);
		b.addActionListener(this);
		b.setActionCommand("chat");

		model = new DefaultComboBoxModel<>();
		model.addAll(cl.map.keySet());
		model.setSelectedItem(model.getElementAt(0));
		cbnc = new JComboBox<String>(model);
		
		JButton change = new JButton("Changer Pseudo");
		change.setBounds(100, 300, 200, 20);
		change.addActionListener(this);
		change.setActionCommand("change");
		
		valid = new JButton("Valider");
		valid.setBounds(100, 400, 200, 20);
		valid.addActionListener(this);
		valid.setActionCommand("valid");
		
		tf1 = new JTextField();
		tf1.setBounds(140, 350, 100, 20);
		
		error = new JTextArea("Erreur ce pseudo est d�j� pris r�essayez");
		error.setBackground(Color.RED);
		error.setBounds(50, 435, 300, 20);
		f.add(error);
		
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cbnc.setBounds(140, 50, 100, 20);
		f.add(cbnc);
		f.add(b);
		f.add(refresh);
		f.add(change);
		f.add(tf1);
		f.add(valid);
		tf1.setVisible(false);
		valid.setVisible(false);
		error.setVisible(false);
		

		f.setSize(400, 500);// 400 width and 500 height
		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible

	}

	public void ft4(String psd, int p, int i) {

		otherDude = psd;
		port = p;
		nb2=i;

		JTextArea txt = new JTextArea("Voulez-vous discuter avec " + psd + " ?");

		f = new JFrame();// creating instance of JFrame

		JButton b1 = new JButton("Accepter");// creating instance of JButton
		JButton b2 = new JButton("Refuser");

		b1.setBounds(100, 100, 100, 40);
		b1.addActionListener(this);
		b1.setActionCommand("accept");

		b2.setBounds(200, 100, 100, 40);
		b2.addActionListener(this);
		b2.setActionCommand("deny");

		txt.setBounds(50, 20, 300, 20);

		f.add(b1);
		f.add(b2);
		f.add(txt);

		f.setSize(400, 500);// 400 width and 500 height
		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible

	}

	public void ft5() {

		f = new JFrame("ChatBox");

		f.setVisible(true);
		JPanel southPanel = new JPanel();
		f.add(BorderLayout.SOUTH, southPanel);
		southPanel.setBackground(Color.BLUE);
		southPanel.setLayout(new GridBagLayout());

		messageBox = new JTextField(30);
		sendMessage = new JButton("Envoyer Message");
		chatBox = new JTextArea();
		chatBox.setEditable(false);
		f.add(new JScrollPane(chatBox), BorderLayout.CENTER);

		ButtonEffect be = new ButtonEffect(nb, chatBox, messageBox, cl, lec.get(nb), cl.engaging);
		sendMessage.addActionListener(be);
		sendMessage.setActionCommand("send");

		chatBox.setLineWrap(true);

		GridBagConstraints left = new GridBagConstraints();
		left.anchor = GridBagConstraints.WEST;
		GridBagConstraints right = new GridBagConstraints();
		right.anchor = GridBagConstraints.EAST;
		right.weightx = 2.0;

		southPanel.add(messageBox, left);
		southPanel.add(sendMessage, right);
		
		f.addWindowListener(new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
		        be.quit();
		    }
		});

		chatBox.setFont(new Font("Serif", Font.PLAIN, 15));
		//f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(600, 600);
		if (!cl.engaging) {
			lec.get(nb).box = chatBox;
			ArrayList<String> al = cl.db.get(port + 2000, cl.map.get(otherDude) + 2000);
			for (int i = 0; i < al.size(); i++)
				chatBox.append(al.get(i) + "\n");
		} else
			cl.lchat.get(nb).box = chatBox;
		cl.engaging=false;
	}

	public void msg(String psd, int p) {

		otherDude = psd;
		port = p;

		try {
			ArrayList<String> al = cl.db.get(port + 2000, cl.map.get(otherDude) + 2000);
			for (int i = 0; i < al.size(); i++)
				chatBox.append(al.get(i));
			lec.add(nb,
					new EngageChat("127.0.0.1", (cl.map.get(otherDude)+(50*nb2) + 2000), "Nouvelle connexion", cl, otherDude));
			cl.lchat.add(nb, null);
			Thread th = new Thread(lec.get(nb));
			th.start();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ft5();
	}
	
	public void refresh() {
		model.removeAllElements();
		model.addAll(cl.map.keySet());
		model.setSelectedItem(model.getElementAt(0));
	}
}

package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class TCPIn implements Runnable {

	BufferedReader in = null;
	Client cl;
	String psd;
	Chat chat;
	int port;

	public TCPIn(BufferedReader in, Client cl, String psd, int port, Chat chat) {
		this.in = in;
		this.cl = cl;
		this.psd = psd;
		this.chat = chat;
		this.port = port;
	}

	@Override
	public void run() {
		System.out.println("TCPIn");
		while (true) {
			try {
				String str = in.readLine();
				while(str == null) {
					str = in.readLine();
					TimeUnit.SECONDS.sleep(2);
				}
				if(str.contains("Nouvelle connexion")) {
					ArrayList<String> al = cl.db.get(chat.link.getLocalPort(), cl.map.get(psd)+2000);
					for(int i =0;i<al.size();i++)
						chat.box.append(al.get(i)+"\n");
				}
				
				if(str.equals("quit")) {
					cl.toDb(port);
					try {
						chat.servSocket.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					cl.msgs.add(psd + " : " + str);
					chat.box.append(psd + " : " + str);
					return;
				}
					
				cl.msgs.add(psd + " : " + str);
				chat.box.append(psd + " : " + str+"\n");
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}

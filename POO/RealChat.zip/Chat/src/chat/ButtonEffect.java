package chat;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ButtonEffect implements ActionListener {

	int nb; 
	JTextArea chatBox;
	JTextField messageBox;
	Client cl;
	EngageChat ec;
	boolean engaging;
	
	public ButtonEffect(int nb,JTextArea chatBox, JTextField messageBox, Client cl, EngageChat ec,
			boolean engaging) {
		this.nb=nb;
		this.chatBox = chatBox;
		this.messageBox = messageBox;
		this.cl = cl;
		this.ec = ec;
		this.engaging = engaging;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();
		if (action.equals("send")) {
			chatBox.append(cl.name + " : " + messageBox.getText() + "\n");
			System.out.println(">>>>>>> " + cl.engaging);
			if(engaging)
				cl.lchat.get(nb).out(messageBox.getText());
			else
				ec.out(messageBox.getText());
		}
	}
	
	public void quit() {
		chatBox.append(cl.name + " : quit\n");
		if(engaging)
			cl.lchat.get(nb).out("quit");
		else
			ec.out("quit");
	}

}

package chat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Database {


	public void insert(int port1, int port2, ArrayList<String> msgs) {
		try {
			Class.forName("org.sqlite.JDBC");
			String currentDirectory = System.getProperty("user.dir");
			String dbURL = "jdbc:sqlite:"+currentDirectory+"/test.db";
			Connection conn = DriverManager.getConnection(dbURL);
			Statement stmt = conn.createStatement();
			if (conn != null) {
				System.out.println("Condfghjknected to the database");
				String database = "d" + port1 + "_" + port2;
				String sql = "CREATE TABLE IF NOT EXISTS " + database + " ( " + "msg VARCHAR(250) NOT NULL)";
				stmt.execute(sql);
				String sql2 = "INSERT INTO " + database + " (msg) VALUES(?)";
				PreparedStatement pstmt = conn.prepareStatement(sql2);
				for (int i = 0; i < msgs.size(); i++) {
					String msg = msgs.get(i);
					pstmt.setString(1, msg);
					pstmt.executeUpdate();
				}
				conn.close();
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public ArrayList<String> get(int port1, int port2) {
		ArrayList<String> al = new ArrayList<String>();
		try {
			Class.forName("org.sqlite.JDBC");
			String currentDirectory = System.getProperty("user.dir");
			String dbURL = "jdbc:sqlite:"+currentDirectory+"/test.db";
			System.out.println(dbURL);
			Connection conn = DriverManager.getConnection(dbURL);
			Statement stmt = conn.createStatement();
			if (conn != null) {
				System.out.println("Connfzefzefzefzected to the database");
				String database = "d" + port1 + "_" + port2;
				String sql = "CREATE TABLE IF NOT EXISTS " + database + " ( " + "msg VARCHAR(250) NOT NULL)";
				System.out.println("table created\n");
				stmt.execute(sql);
				sql = "SELECT msg FROM " + database;
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					al.add(rs.getString("msg"));
				}
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		System.out.println("Returning\n");
		return al;
	}
}

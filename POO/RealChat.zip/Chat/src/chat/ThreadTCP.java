package chat;

import java.io.*;
import java.net.*;


public class ThreadTCP implements Runnable {
    private ServerSocket servSocket;
    private Socket link;
    private String response="";
    public boolean connected = false;
   // public Thread th;
    

    public ThreadTCP(ServerSocket servSocket) {
        this.servSocket = servSocket;
    }

    public void run() {
       // th = new Thread(this);
    	try {
			link = servSocket.accept();
			System.out.println("Accepted");
		} catch (IOException e1) {
			
		}
    	connected = true;
        BufferedReader in = null;
        if(link==null)
        	return;
        try {
            in = new BufferedReader(new InputStreamReader(this.link.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        PrintWriter out = null;
        try {
            out = new PrintWriter(this.link.getOutputStream(),true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Re�u serv");
        //4
        try {
            String input = in.readLine();
            response= input;
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Envoi serv");
        out.println("ok");

    }
    
    public String getResponse() {
    	return response;
    }
}


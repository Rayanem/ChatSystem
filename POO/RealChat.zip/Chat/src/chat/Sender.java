package chat;

import java.io.IOException;
import java.net.*;
import java.util.Arrays;

public class Sender {
	int port;
	int src;
	
	public Sender(int port,int src) {
		this.port=port;
		this.src = src;
	}
    
    public void newPseudo(String envoi){
    	send(envoi,127);
    }
    
    public void pseudoAccepted(String envoi){
    	send(envoi,2);
     }
    
    public void message(String envoi,int nb) {
    	send(envoi,3+nb);
    }
    
    private void send(String envoi, int id) {
    	
        System.out.println(src);
        byte[] byteArray = new byte[]{ (byte) id,(byte) (src-2500)};
        byte[] buffertemp = envoi.getBytes();
        /*
        byte[] buffer = Arrays.copyOf(buffertemp, buffertemp.length + 1);
        buffer[0] = byteArray;*/
        byte[] buffer = Arrays.copyOf(byteArray, byteArray.length + buffertemp.length);
        System.arraycopy(buffertemp, 0, buffer, byteArray.length, buffertemp.length);
    	try {
            //On initialise la connexion c�t� client
            DatagramSocket client = new DatagramSocket();
            
            //On cr�e notre datagramme
            InetAddress adresse = InetAddress.getByName("127.0.0.1");
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, adresse, port);
            
            //On lui affecte les donn�es � envoyer
            packet.setData(buffer);
            
            //On envoie au serveur
            client.send(packet);
            
            
            client.close();
            
         } catch (SocketException e) {
            e.printStackTrace();
         } catch (UnknownHostException e) {
            e.printStackTrace();
         } catch (IOException e) {
            e.printStackTrace();
         }
    }
 }   
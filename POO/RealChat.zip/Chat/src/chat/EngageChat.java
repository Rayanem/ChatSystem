package chat;

import java.net.*;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import javax.swing.JTextArea;

import java.io.*;

public class EngageChat implements Runnable {
	Socket socket;
	String str;
	String s;
	Client cl;
	int port;
	String psd;
	boolean stop = false;
	final BufferedReader parameter;
	Thread t;
	PrintWriter out;
	JTextArea box;

	public EngageChat(String server, int port, String s, Client cl, String psd) throws IOException {
		// 1 Create server Socket
		System.out.println(port);
		socket = new Socket(server, port);
		this.port = port;
		this.s = s;
		this.cl = cl;
		this.psd = psd;
		
		BufferedReader in = null;
		try {
			in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		parameter = in;
	}

	public void run() {

		t = new Thread(new Runnable() {
			public void run() {
				while (!stop) {
					try {
						if (parameter.ready()) {
							try {
								str = parameter.readLine();
								if (str.equals("quit")) {
									stop = true;
								}

							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if (str != null) {
								box.append(psd + " : " + str+"\n");
								cl.msgs.add(psd + " : " + str);
							}
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				cl.toDb(port - 2000);
				try {
					socket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		t.start();
		prepOut();
	}
	
	public void prepOut() {
		out = null;
		try {
			out = new PrintWriter(this.socket.getOutputStream(), true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.println(s);
	}
	public void out(String outStr) {
			cl.msgs.add(cl.name + " : " + outStr);
			if (outStr.equals("quit")) {
				out.println(outStr);
				out.flush();
				cl.toDb((port%50) - 2000);
				stop = true;
				try {
					parameter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				t.interrupt();
				try {
					socket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			out.println(outStr);
			out.flush();
	}
}
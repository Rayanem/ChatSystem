package chat;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Main {
	public static void main(String[] args) {

		Interface in = new Interface();
		
		in.ft();
	}

}
